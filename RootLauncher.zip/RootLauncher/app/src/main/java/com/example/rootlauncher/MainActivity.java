package com.example.rootlauncher;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            File script = new File(getFilesDir(), "run.sh");
            try (InputStream in = getAssets().open("run.sh");
                 OutputStream out = new FileOutputStream(script)) {
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            script.setExecutable(true, false);
            Runtime.getRuntime().exec(new String[]{"su", "-c", "sh " + script.getAbsolutePath()});
        } catch (Exception e) {
            Toast.makeText(this, "Ошибка: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        finish();
    }
}
