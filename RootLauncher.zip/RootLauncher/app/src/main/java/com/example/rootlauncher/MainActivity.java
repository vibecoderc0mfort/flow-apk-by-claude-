package com.example.rootlauncher;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private TextView log;
    private ScrollView scroll;
    private SharedPreferences prefs;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(40), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("Game Launcher");
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, wrap());

        Button run = new Button(this);
        run.setText("Запустить скрипт");
        run.setOnClickListener(v -> runScript());
        root.addView(run, wrap());

        Button check = new Button(this);
        check.setText("Проверить root");
        check.setOnClickListener(v -> execRoot("id", false));
        root.addView(check, wrap());

        Button copy = new Button(this);
        copy.setText("Копировать лог");
        copy.setOnClickListener(v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("log", log.getText()));
            Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show();
        });
        root.addView(copy, wrap());

        CheckBox auto = new CheckBox(this);
        auto.setText("Запускать сразу при открытии");
        auto.setChecked(prefs.getBoolean("auto", false));
        auto.setOnCheckedChangeListener((b, c) -> prefs.edit().putBoolean("auto", c).apply());
        root.addView(auto, wrap());

        scroll = new ScrollView(this);
        log = new TextView(this);
        log.setTypeface(Typeface.MONOSPACE);
        log.setTextSize(12);
        log.setTextIsSelectable(true);
        scroll.addView(log);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        append("Готов. Нажмите «Запустить скрипт».\n");

        if (prefs.getBoolean("auto", false)) runScript();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void append(final String s) {
        ui.post(() -> {
            log.append(s);
            if (log.length() > 100000) {
                CharSequence t = log.getText();
                log.setText(t.subSequence(t.length() - 60000, t.length()));
            }
            scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
        });
    }

    private File prepareScript() throws Exception {
        File f = new File(getFilesDir(), "run.sh");
        long upd = getPackageManager().getPackageInfo(getPackageName(), 0).lastUpdateTime;
        if (!f.exists() || prefs.getLong("upd", 0) != upd) {
            append("Копирую скрипт из APK...\n");
            try (InputStream in = getAssets().open("run.sh");
                 OutputStream out = new FileOutputStream(f)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            prefs.edit().putLong("upd", upd).apply();
            append("Готово: " + (f.length() / 1024) + " КБ\n");
        }
        f.setReadable(true, false);
        f.setExecutable(true, false);
        return f;
    }

    private void runScript() {
        execRoot(null, true);
    }

    private void execRoot(final String cmd, final boolean script) {
        new Thread(() -> {
            try {
                String full = cmd;
                if (script) {
                    File f = prepareScript();
                    full = "sh " + f.getAbsolutePath();
                }
                append("\n$ su -c \"" + full + "\"\n");
                Process p = new ProcessBuilder("su", "-c", full)
                        .redirectErrorStream(true).start();
                try (BufferedReader r = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = r.readLine()) != null) append(line + "\n");
                }
                append("[код завершения: " + p.waitFor() + "]\n");
            } catch (Exception e) {
                append("ОШИБКА: " + e + "\n(нет root или su не найден?)\n");
            }
        }).start();
    }
}
