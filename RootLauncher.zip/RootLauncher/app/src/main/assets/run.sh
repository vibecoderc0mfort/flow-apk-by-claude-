#!/system/bin/sh
# ВСТАВЬТЕ СЮДА СВОЙ СКРИПТ (замените содержимое этого файла)
# Пример запуска игры:
# monkey -p com.пакет.игры -c android.intent.category.LAUNCHER 1
