1. Замените app/src/main/assets/run.sh своим скриптом.
2. Откройте проект в AIDE / Android Studio и соберите APK
   (Build > Build APK, либо в Termux: gradle assembleDebug).
3. Установите app/build/outputs/apk/debug/app-debug.apk.
4. При первом запуске выдайте root-доступ в Magisk/KernelSU.
Имя пакета и название можно поменять в app/build.gradle и AndroidManifest.xml.
